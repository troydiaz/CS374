/*
*   INSTRUCTIONS ON HOW TO COMPILE AND RUN!!!
* 
*   Compile the program as follows:
*
*       rustc main.rs
*
*   Run the executable:
*
*       ./main
*
*/