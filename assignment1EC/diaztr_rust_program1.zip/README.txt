/*
*   INSTRUCTIONS ON HOW TO COMPILE, RUN, AND CHECK FOR MEMORY LEAKS!!!
*   Process the file provided as an argument to the program to
*   create a linked list of student structs and print out the list.
*   Compile the program as follows:
*       rustc main.rs -o movies
*   Run the executable:
*       ./movies movies_info.csv
*/